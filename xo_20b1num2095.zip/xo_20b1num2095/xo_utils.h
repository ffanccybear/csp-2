#ifndef XO_UTILS_H
#define XO_UTILS_H

#include "csapp.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BOARD_SIZE 20
#define STREAK 5

char board[BOARD_SIZE][BOARD_SIZE];

void initializeBoard() {
    memset(board, '_', sizeof(board));
}

void displayBoard() {
    system("clear");
    printf("  ");
    for (int i = 0; i < BOARD_SIZE; i++) {
        printf(" %2d", i);
    }
    printf("\n");
    
    for (int i = 0; i < BOARD_SIZE; i++) {
        printf(" %2d", i);
        for (int j = 0; j < BOARD_SIZE; j++) {
            printf(" %c ", board[i][j]);
        }
        printf("\n");
    }
}

int placeMarker(int x, int y, char marker) {
    if (x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE || board[x][y] != '_')
        return 1;
    
    board[x][y] = marker;
    return 0;
}

int checkForWinner(int x, int y) {
    const char player = board[x][y];
    if (player == '_')
        return 0;

    int directions[4][2] = {{1, 0}, {0, 1}, {1, 1}, {1, -1}};
    for (int i = 0; i < 4; i++) {
        int count = 1;
        for (int j = 1; j < STREAK; j++) {
            int nx = x + directions[i][0] * j;
            int ny = y + directions[i][1] * j;
            if (nx < 0 || nx >= BOARD_SIZE || ny < 0 || ny >= BOARD_SIZE || board[nx][ny] != player)
                break;
            count++;
        }
        if (count == STREAK) return 1;
    }
    return 0;
}

int evaluateGameState() {
    int emptyFound = 0;
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            if (board[i][j] == '_') {
                emptyFound = 1;
            } else if (checkForWinner(i, j)) {
                displayBoard();
                printf("%c wins!\n", board[i][j]);
                return 1;
            }
        }
    }
    if (!emptyFound) {
        displayBoard();
        printf("draw \n");
        return 1;
    }
    return 0;
}

#endif
