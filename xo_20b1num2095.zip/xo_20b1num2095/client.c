#include "xo_utils.h"
#include <limits.h>

void startGame(int sockfd) {
    char buff[BOARD_SIZE * BOARD_SIZE];
    char input[100];
    int x, y, gameRunning = 1, n;

    while (gameRunning) {
        displayBoard();
        do {
            printf("You are player O\n");
            printf("Enter the coordinates (x y): ");
            if (fgets(input, sizeof(input), stdin) == NULL)
                break;

            n = sscanf(input, "%d %d", &x, &y);
            if (n != 2 || x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE) {
                printf("wrong coordinates, try again.\n");
                continue;
            }
        } while (placeMarker(x, y, 'O'));

        displayBoard();
        memcpy(buff, board, sizeof(buff));
        Rio_writen(sockfd, buff, sizeof(buff));

        if (evaluateGameState()) {
            gameRunning = 0;
            continue;
        }

        Rio_readn(sockfd, buff, sizeof(buff));
        memcpy(board, buff, sizeof(buff));

        if (evaluateGameState()) {
            gameRunning = 0;
            continue;
        }
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(0);
    }
    
    int port = atoi(argv[1]);
    initializeBoard();

    int sockfd = Socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in servaddr = {0};

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(port);
    Connect(sockfd, (SA *)&servaddr, sizeof(servaddr));

    startGame(sockfd);
    Close(sockfd);
    return 0;
}
