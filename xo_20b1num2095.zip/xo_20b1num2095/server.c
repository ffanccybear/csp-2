#include "xo_utils.h"
#include <limits.h>

void startGame(int connfd) {
    char buff[BOARD_SIZE * BOARD_SIZE];
    char input[100];
    int x, y, n;

    while (1) {
        bzero(buff, sizeof(buff));
        Rio_readn(connfd, buff, sizeof(buff));
        
        if (strlen(buff) == 0) break;
        
        memcpy(board, buff, sizeof(buff));
        displayBoard();
        
        if (evaluateGameState()) break;
        
        do {
            printf("You are player X\n");
            printf("Enter the coordinates (x y): ");
            if (fgets(input, sizeof(input), stdin) == NULL)
                break;
            
            n = sscanf(input, "%d %d", &x, &y);
            if (n != 2 || x < 0 || x >= BOARD_SIZE || y < 0 || y >= BOARD_SIZE) {
                printf("Invalid coordinates. Please try again.\n");
                continue;
            }
        } while (placeMarker(x, y, 'X'));
        
        displayBoard();
        memcpy(buff, board, sizeof(buff));
        Rio_writen(connfd, buff, sizeof(buff));
    }
}

int main(int argc, char **argv) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <port>\n", argv[0]);
        exit(0);
    }
    
    int port = atoi(argv[1]);
    initializeBoard();

    int listenfd = Open_listenfd(argv[1]);
    struct sockaddr_storage clientaddr;
    socklen_t clientlen = sizeof(struct sockaddr_storage);
    
    int connfd = Accept(listenfd, (SA *)&clientaddr, &clientlen);
    startGame(connfd);
    Close(connfd);
    Close(listenfd);
    return 0;
}
