#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "csapp.h"


#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define MAX_AGE 300 

/* You won't lose style points for including this long line in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

typedef struct cache_item {
    char *uri;
    char *data;
    int size;
    time_t timestamp;
    struct cache_item *prev, *next;
    sem_t mutex;
} cache_item_t;

typedef struct {
    cache_item_t *head, *tail;
    int total_size;
    sem_t mutex;
} cache_t;

cache_t cache;

void init_cache();
void insert_cache(char *uri, char *data, int size);
cache_item_t* find_cache(char *uri);
void delete_cache_item(cache_item_t *item);

static void parse_uri(char *uri, char *hostname, char *port, char *filepath);
static void build_request_header(rio_t *rp, char *req_hd, char *hostname);
void *thread_op(void *vargp);
void doit(int fd);

int main(int argc, char **argv)
{
    char *server_port;
    int listenfd;
    int *connfdp;
    socklen_t clientlen;
    struct sockaddr_storage clientadr;
    char hostname[MAXLINE];
    char port[MAXLINE];
    pthread_t tid;

    if (argc != 2){
        fprintf(
            stderr, 
            "usage: %s <port>\n", 
            argv[0]
        );
        exit(0);
    }

    Signal(SIGPIPE, SIG_IGN);

    server_port = argv[1];
    listenfd = Open_listenfd(server_port);

    init_cache();

    while(1) {
        // clientlen = sizeof(clientadr)
        clientlen = sizeof(struct sockaddr_storage);
        connfdp = Malloc(sizeof(int)); // connection file descriptor-t malloc hiij memory nuutslunu
        *connfdp = Accept(listenfd, (SA *)&clientadr, &clientlen); // connection iig ni avna
        Getnameinfo((SA *) &clientadr, clientlen, hostname, MAXLINE, port, MAXLINE, 0);
        printf(" Accepted connection from (%s %s)\n", hostname, port);
        Pthread_create(&tid, NULL, thread_op, connfdp); // connection-d zoriulj shine thread uusgene
    }

    // printf("%s", user_agent_hdr);

    return 0;
}

void *thread_op(void *vargp){
    int connfd = *((int *) vargp);
    // pthread_t tid = pthread_self()
    // printf("aa", tid);
    Pthread_detach(pthread_self()); 
    Free(vargp); 
    doit(connfd);
    Close(connfd);
    return NULL;
}

static void parse_uri(char *uri, char *hostname, char *port, char *filepath){
    char *p1;
    char *p2; 

    uri += 7; // http://-g algasah

    p1 = strchr(uri, ':');
    *p1 = '\0';
    p1++;
    strcpy(hostname, uri); // copy hostname

    p2 = strchr(p1, '/');
    *p2 = '\0';
    strcpy(port, p1);
    strcpy(filepath, "/");
    strcat(filepath, p2+1); // copy filepath
}

static void build_request_header(rio_t *rp, char *req_header, char *hostname){
    char buf[MAXLINE];

    while (Rio_readlineb(rp, buf, MAXLINE) > 0){
        if (!strcmp(buf, "\r\n")) {
            break; // EOH
        }

        if (strstr(buf, "Host:") != NULL){
            continue;
        }

        if (strstr(buf, "User-Agent:") != NULL) {
            continue;
        }

        if (strstr(buf, "Connection:") != NULL){
            continue;
        }

        if (strstr(buf, "Proxy-Connection:") != NULL){
            continue;
        }

        strcat(req_header, buf); // header iig bufferlu nemne
    }

    sprintf(buf, "Host: %s\r\n", hostname);
    strcat(req_header, buf);

    sprintf(buf, "User-Agent: %s", user_agent_hdr);
    strcat(req_header, buf);

    strcat(req_header, "Connection: false\r\n");
    strcat(req_header, "Proxy-Connection: false\r\n");
    strcat(req_header, "\r\n");
}

void doit(int clientfd) {
    rio_t rio_client, rio_server;
    char buf[MAXLINE];
    char method[MAXLINE]; 
    char uri[MAXLINE];
    char version[MAXLINE];
    char hostname[MAXLINE];
    char filepath[MAXLINE]; 
    char server_port[MAXLINE];
    char req_header[MAXLINE]; 
    char cache_key[MAXLINE];
    int serverfd;

    Rio_readinitb(&rio_client, clientfd);

    if (!Rio_readlineb(&rio_client, buf, MAXLINE)) {
        return;
    }

    sscanf(buf, "%s %s %s", method, uri, version);

    if (strcasecmp(method, "GET")) {
        return;
    }

    if (!strcmp(version, "HTTP/1.1")) {
        strcpy(version, "HTTP/1.0");
    }

    parse_uri(uri, hostname, server_port, filepath);
    sprintf(cache_key, "%s:%s%s", hostname, server_port, filepath); // cache key uusgeh

    cache_item_t *cache_item = find_cache(cache_key);
    if (cache_item) {
        Rio_writen(clientfd, cache_item->data, cache_item->size); // cache hiisen response iig yavuulna
        V(&cache_item->mutex); 
        return;
    }

    serverfd = Open_clientfd(hostname, server_port);
    Rio_readinitb(&rio_server, serverfd);

    // browseroos http req-iig unshih
    // request line iig uusgeh
    sprintf(req_header, "GET /%s %s\r\n", filepath, version);
    build_request_header(&rio_client, req_header, hostname);


    // client browser deer, http response yavuulah
    Rio_writen(serverfd, req_header, strlen(req_header));

    char *response = (char *)malloc(MAX_OBJECT_SIZE);
    bzero(response, MAX_OBJECT_SIZE);
    int total_size = 0;
    ssize_t n;

    while ((n = Rio_readlineb(&rio_server, buf, MAXLINE)) > 0) {
        Rio_writen(clientfd, buf, n);
        if (total_size + n < MAX_OBJECT_SIZE) { // 
            memcpy(response + total_size, buf, n);
        }
        total_size += n;
    }

    if (total_size < MAX_OBJECT_SIZE) { // response iig ni cache ruu hadgalah
        insert_cache(cache_key, response, total_size);
    }

    free(response); // response buffer iig chuluulnu
    Close(serverfd);
}

void init_cache() {
    cache.head = NULL; // cache list iin head
    cache.tail = NULL; // cache list iin tail
    cache.total_size = 0; // 
    Sem_init(&cache.mutex, 0, 1) ; // mutex semaphore iig 1 bolgoh
}

void insert_cache(char *uri, char *data, int size) {
    if (size > MAX_OBJECT_SIZE) {
        // size hetervel cachelahgui
        return;
    }

    // cache init hiine
    cache_item_t *new_item = (cache_item_t *)malloc(sizeof(cache_item_t));
    new_item->uri = strdup(uri); // uri aa dup hiine
    new_item->data = (char *)malloc(size); 
    memcpy(new_item->data, data, size); // new_item iin data-g huulna
    new_item->size = size; // new_item iin size-g avna
    new_item->timestamp = time(NULL); // odoo baigaa tsagiig timestamp bolgoj avna
    Sem_init(&new_item->mutex, 0, 1); // new_item-d mutex semaphore

    P(&cache.mutex); // cache aa tugjine

    // hervee cache iin hemjee max cache aas hetervel
    // hamgiin baga hereglegdsen item uuda hasna
    while (cache.total_size + size > MAX_CACHE_SIZE) {
        cache_item_t *old_item = cache.head; // hamgiin baga hereglegdsen ni 
        cache.head = cache.head->next; // head iig ni next item ruu zaana
        if (cache.head) {
            cache.head->prev = NULL; // umnuh head iin pointer iig null bolgono
        } else {
            cache.tail = NULL; // hervee odoo baigaa cache hooson baival tail iig ni null bolgono
        }

        // end cleaning hiine.
        cache.total_size -= old_item->size;
        free(old_item->uri);
        free(old_item->data);
        free(old_item);
    }

    // cache list iin tail hesegt shine item nemeh
    if (!cache.head) {
        cache.head = cache.tail = new_item;
        new_item->prev = new_item->next = NULL;
    } else {
        // jo list uildluud xD
        new_item->prev = cache.tail;
        new_item->next = NULL;
        cache.tail->next = new_item;
        cache.tail = new_item;
    }

    cache.total_size += size;
    V(&cache.mutex);
}

cache_item_t* find_cache(char *uri) { // URI aar ni cache iin item oloh
    P(&cache.mutex); 

    cache_item_t *item = cache.head; // head ees ni ehleed davtaad uri aar ni tulgaad yavna
    while (item) {
        if (strcmp(item->uri, uri) == 0) { // hervee oldvol update.
            item->timestamp = time(NULL);
            V(&cache.mutex);
            P(&item->mutex);
            return item;
        }
        item = item->next;
    }
    // hervee cache item oldoogui bol cache aa unlock hiiged null butsaana
    V(&cache.mutex);
    return NULL;
}


void delete_cache_item(cache_item_t *item) {
    P(&cache.mutex);

    // cache list ees ustgahiin tuld umnuh bolon daraagiin pointeriig update hiine
    if (item->prev) {
        item->prev->next = item->next;
    } else {
        cache.head = item->next;
    }

    if (item->next) {
        item->next->prev = item->prev;
    } else {
        cache.tail = item->prev;
    }

    cache.total_size -= item->size;

    free(item->uri);
    free(item->data);
    free(item);

    V(&cache.mutex);
}
