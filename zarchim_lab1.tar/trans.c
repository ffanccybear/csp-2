/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"

#define min(a,b) (((a) < (b)) ? (a) : (b))

int is_transpose(int M, int N, int A[N][M], int B[M][N]);
void matrix_transpose_32x32(int rows, int cols, int source[rows][cols], int target[cols][rows]);
void matrix_transpose_64x64(int rows, int cols, int source[rows][cols], int target[cols][rows]);
void matrix_transpose_61x67(int rows, int cols, int source[rows][cols], int target[cols][rows]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    if(M == 32 && N == 32)
        matrix_transpose_32x32(N, M, A, B);
    else if(M == 64 && N == 64)
        matrix_transpose_64x64(N, M, A, B);
    else if(M == 61 && N == 67)
        matrix_transpose_61x67(N, M, A, B);
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

void matrix_transpose_32x32(int rows, int cols, int source[rows][cols], int target[cols][rows]) {
    int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;
    int x, y;
    int blockSize = 8;
    for(x = 0; x < rows; x += blockSize) {
        for(y = 0; y < cols; y += blockSize) {
            for(int z = x; z < x + blockSize && z < rows; z++) {
                temp0 = source[z][y];
                temp1 = source[z][y + 1];
                temp2 = source[z][y + 2];
                temp3 = source[z][y + 3];
                temp4 = source[z][y + 4];
                temp5 = source[z][y + 5];
                temp6 = source[z][y + 6];
                temp7 = source[z][y + 7];
                target[y][z] = temp0;
                target[y + 1][z] = temp1;
                target[y + 2][z] = temp2;
                target[y + 3][z] = temp3;
                target[y + 4][z] = temp4;
                target[y + 5][z] = temp5;
                target[y + 6][z] = temp6;
                target[y + 7][z] = temp7;
            }
        }
    }
}

void matrix_transpose_61x67(int rows, int cols, int source[rows][cols], int target[cols][rows]) {
    int x, y, m, n;
    int blockSize = 16;
    for(x = 0; x < rows; x += blockSize) {
        for(y = 0; y < cols; y += blockSize) {
            for(m = x; m < x + blockSize && m < rows; m++) {
                for(n = y; n < y + blockSize && n < cols; n++) {
                    target[n][m] = source[m][n];
                }
            }
        }
    }
}

void matrix_transpose_64x64(int rows, int cols, int source[rows][cols], int target[cols][rows]) {
    int x, y, m, k;
    int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7, swapTemp;
    int blockSize = 8;
    for(x = 0; x < rows; x += blockSize) {
        for(y = 0; y < cols; y += blockSize) {
            for(m = 0; m < blockSize / 2; m++) {
                temp0 = source[x + m][y];
                temp1 = source[x + m][y + 1];
                temp2 = source[x + m][y + 2];
                temp3 = source[x + m][y + 3];
                temp4 = source[x + m][y + 4];
                temp5 = source[x + m][y + 5];
                temp6 = source[x + m][y + 6];
                temp7 = source[x + m][y + 7];

                target[y][x + m] = temp0;
                target[y + 1][x + m] = temp1;
                target[y + 2][x + m] = temp2;
                target[y + 3][x + m] = temp3;

                target[y][x + m + blockSize / 2] = temp4;
                target[y + 1][x + m + blockSize / 2] = temp5;
                target[y + 2][x + m + blockSize / 2] = temp6;
                target[y + 3][x + m + blockSize / 2] = temp7;
            }
            for(k = 0; k < blockSize / 2; k++) {
                temp0 = source[x + 4][y + k], temp4 = source[x + 4][y + k + 4];
                temp1 = source[x + 5][y + k], temp5 = source[x + 5][y + k + 4];
                temp2 = source[x + 6][y + k], temp6 = source[x + 6][y + k + 4];
                temp3 = source[x + 7][y + k], temp7 = source[x + 7][y + k + 4];

                swapTemp = target[y + k][x + 4], target[y + k][x + 4] = temp0, temp0 = swapTemp;
                swapTemp = target[y + k][x + 5], target[y + k][x + 5] = temp1, temp1 = swapTemp;
                swapTemp = target[y + k][x + 6], target[y + k][x + 6] = temp2, temp2 = swapTemp;
                swapTemp = target[y + k][x + 7], target[y + k][x + 7] = temp3, temp3 = swapTemp;

                target[y + k + 4][x + 0] = temp0, target[y + k + 4][x + 4] = temp4;
                target[y + k + 4][x + 1] = temp1, target[y + k + 4][x + 5] = temp5;
                target[y + k + 4][x + 2] = temp2, target[y + k + 4][x + 6] = temp6;
                target[y + k + 4][x + 3] = temp3, target[y + k + 4][x + 7] = temp7;
            }
        }
    }
}


/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}
