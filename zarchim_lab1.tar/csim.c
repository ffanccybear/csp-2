#include "cachelab.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <assert.h>

#define MAXSIZE 110
typedef unsigned long long uint64;

char input[MAXSIZE];

extern char *optarg;
extern int optopt, optind, opterr;

int S, s, E, b, B;

int hit = 0;
int miss = 0;
int eviction = 0;

uint64 read_addr(const char *str) {
    const char *start_addr = str + 3; // эхний 3 ийг алгасна
    char *end_ptr;
    uint64 address = strtoull(start_addr, &end_ptr, 16);

    if (*end_ptr != ',') {
        fprintf(stderr, "Error: Expected a comma after the address in the input string '%s'\n", str);
        exit(EXIT_FAILURE);
    }

    return address;
}

void cache_1(int (*cache)[E], int (*valid)[E], uint64 addr) {
    static size_t access_counter = 0;

    uint64 mask = S - 1; // сүүлийн 3 битийг авахад хэрэглэнэ
    uint64 group = (addr >> b) & mask;  // set index bits
    uint64 tag = addr >> (s + b); // s = set index bits, b = block offset bit => зөвхөн tag bit-үүд үлдэнэ гэсэн үг.

    for (int i = 0; i < E; i++) {
        if (valid[group][i] && cache[group][i] == tag) {
            ++hit; // cache hit
            valid[group][i] = ++access_counter; // update access time
            return;
        }
    }

    ++miss;

    size_t min_access_time = valid[group][0];
    size_t lru = 0;
    for (int i = 1; i < E; ++i) {
        if (valid[group][i] < min_access_time) {
            min_access_time = valid[group][i];
            lru = i;
        }
    }

    if (min_access_time > 0) {
        ++eviction;
    }

    cache[group][lru] = tag;
    valid[group][lru] = ++access_counter;
}

void cache_2(int (*cache)[E], int (*valid)[E], uint64 addr) {
    cache_1(cache, valid, addr);
    ++hit;
}

int main(int argc, char **argv) {
    FILE *fp = NULL;
    char op;
    while ((op = getopt(argc, argv, "hvs:E:b:t:")) != -1) {
        printf("optind = %d, op = %c\n", optind, op);
        switch (op) {
            case 'h':
                puts("option: -h");
                break;
            case 'v':
                puts("option: -v");
                break;
            case 's':
                s = atoi(optarg);
                printf("option: -s %d\n", s);
                break;
            case 'E':
                E = atoi(optarg);
                printf("option: -E %d\n", E);
                break;
            case 'b':
                b = atoi(optarg);
                printf("option: -b %d\n", b);
                break;
            case 't':
                printf("option: -t %s\n", optarg);
                fp = fopen(optarg, "r");
                if (fp == NULL) {
                    fprintf(stderr, "Error: Could not open file %s\n", optarg);
                    exit(EXIT_FAILURE);
                }
                break;
            default:
                printf("Unknown option: %c\n", optopt);
        }
    }

    S = 1 << s;
    B = 1 << b;

    int (*cache)[E] = (int(*)[E])malloc(sizeof(int) * S * E);
    int (*valid)[E] = (int(*)[E])malloc(sizeof(int) * S * E);

    if (!cache || !valid) {
        puts("Error: run out of memory");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < S; i++) {
        for (int j = 0; j < E; j++) {
            cache[i][j] = 0;
            valid[i][j] = 0;
        }
    }

    uint64 addr; //
    while (fgets(input, MAXSIZE, fp)) {
        if (input[0] == 'I') {
            continue;
        }
        assert(input[0] == ' ');
        assert(input[1] == 'L' || input[1] == 'S' || input[1] == 'M');
        addr = read_addr(input);

        if (input[1] == 'L' || input[1] == 'S') {
            cache_1(cache, valid, addr);
        } else {
            cache_2(cache, valid, addr);
        }
    }

    fclose(fp);

    free(cache);   
    free(valid);

    printSummary(hit, miss, eviction);
    return 0;
}
